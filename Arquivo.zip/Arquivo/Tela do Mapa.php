<!-- Não Finalizada, só siga com o botão -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela do Mapa</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <button class="button-31" role="button" onclick="window.open('Tela de Selecionar.php');">Passar de Tela</button>
</body>
</html>