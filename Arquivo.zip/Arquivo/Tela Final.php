<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela Final</title>
    <link href="style.css" rel="stylesheet">
    <script>
        function confirmar()
    {
        alert("Cadastro Realizado com Sucesso!");
    }
    </script>
</head>
<body>
    <center>
    <h1>Dados Pessoais</h1>
     <div>
    <div class="login-box">
    <div class="user-box">
    <label>Nome</label>
      <input type="text" name="" required="">
    </div>
    <div class="user-box">
    <label>Telefone</label>
      <input type="text" name="" required="">
    </div>
    <div class="user-box">
    <label>Email</label>
      <input type="text" name="" required="">
    </div>
    <br>
    <button class="button-31" role="button" onclick="confirmar()">Confirmar</button>
    </div>
    </div>
    </div>
    </center>
</body>
</html>