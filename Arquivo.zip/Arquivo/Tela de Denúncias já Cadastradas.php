<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Denúncias</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
  <center>
     <div>
     <button class="button-31" role="button" onclick="window.open('Tela Inicial.php');">Voltar</button>
    <br> 
    <div class="login-box">
    <div class="user-box">
    <label>Número do Protocolo</label>
      <input type="text" name="" required="" disabled="disabled">
    </div>
    <div class="user-box">
    <label>Status</label>
      <input type="text" name="" required="" disabled="disabled">
    </div>
    <div class="user-box">
    <label>Data</label>
      <input type="text" name="" required="" disabled="disabled">
    </div>
    </div>
    </div>
    </div>
    </center>
</body>
</html>