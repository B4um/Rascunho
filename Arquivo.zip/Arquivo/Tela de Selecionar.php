<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Selecionar Problema</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
<div>
    <center>
    <h1>Selecione um Problema</h1>
    <button class="button-2" role="button" onclick="window.open('Tela Final.php');">Lâmpadas Queimadas</button>
    <br><br>
    <button class="button-2" role="button"  onclick="window.open('Tela Final.php');">Lâmpadas Acesas ao Dia</button>
    <br><br>
    <button class="button-2" role="button" onclick="window.open('Tela Final.php');">Lâmpadas Oscilando</button>
    <br><br>
    <button class="button-2" role="button"  onclick="window.open('Tela Final.php');">Poste Denificado</button>
    </div>
    </center>
</body>
</html>