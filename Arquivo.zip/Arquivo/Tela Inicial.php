<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ILUMINAÇÃO EM FOCO</title>     
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div>
    <img src="IMGS/logo.jpg" class="IMG" alt="">
    <br><br>
    <button class="button-2" role="button" onclick="window.open('Tela do Mapa.php');">Cadastrar Relatório</button>
    <br><br>
    <button class="button-2" role="button"  onclick="window.open('Tela de Denúncias já Cadastradas.php');">Visualizar Denúncias</button>
    </div>

</body>
</html>